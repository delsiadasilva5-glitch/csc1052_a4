from django.contrib import admin

# Nothing needed here for this project
